use anyhow::Result;
use dotenvy_macro::dotenv;
use redis::Client;
use sqlx::mysql::{MySqlPool, MySqlPoolOptions};
use std::time::Duration;

pub async fn create_mysql_pool() -> Result<MySqlPool> {
    let database_url = dotenv!("DATABASE_URL");

    let pool = MySqlPoolOptions::new()
        .max_connections(20) //最大连接数
        .min_connections(5) //最小连接数
        .idle_timeout(Duration::from_secs(60)) //60秒 空闲超时
        .max_lifetime(Duration::from_secs(1800)) //1800秒 30分钟 最大生命周期
        .acquire_timeout(Duration::from_secs(30)) //30秒 获取连接超时
        .test_before_acquire(true) //连接池中连接超时后，重新连接
        .connect(database_url) //连接数据库
        .await?;

    println!("mysql连接成功");
    Ok(pool)
}

pub async fn create_redis_pool() -> Result<Client> {
    let redis_url = dotenv!("REDIS_URL");
    // 创建客户端
    let client = redis::Client::open(redis_url)?;

    // 测试连接
    let mut conn = client.get_async_connection().await?;
    redis::cmd("PING")
        .query_async::<_, String>(&mut conn)
        .await?;
    
    println!("Redis连接成功");
    
    Ok(client)
}
