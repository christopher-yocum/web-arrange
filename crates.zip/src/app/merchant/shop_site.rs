use crate::app::merchant::check::{
    validate_collection_team, validate_risk_control_team, validate_website,
};
use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::ServerError;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one, update_data_sql};
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

/// 购物网站表名
const TABLE: &str = "shop_site";
/// 购物网站显示字段
const DISPLAY_FIELDS: &str =
    "id,upload_time,website,collection_team,risk_control_team,note,enabled";

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Validate)]
struct AddShopSite {
    #[validate(custom(function = "validate_website", code = "website"))]
    website: String, //1 网站
    #[validate(custom(function = "validate_collection_team", code = "collection_team"))]
    collection_team: i32, //2 收款组
    #[validate(custom(function = "validate_risk_control_team", code = "risk_control_team"))]
    risk_control_team: i32, //3 风控组
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Validate)]
struct ChangeShopSite {
    id: i32,
    #[validate(custom(function = "validate_website", code = "website"))]
    website: String,
    #[validate(custom(function = "validate_collection_team", code = "collection_team"))]
    collection_team: i32,
    #[validate(custom(function = "validate_risk_control_team", code = "risk_control_team"))]
    risk_control_team: i32,
    note: String,
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize)]
struct GetShopSite {
    id: i32,                    //1 主键
    upload_time: NaiveDateTime, //2 上传时间
    website: String,            //3 网站
    collection_team: i32,       //4 收款组
    risk_control_team: i32,     //5 风控组
    note: String,               //6 备注
    enabled: i32,               //7 是否启用
}

#[derive(Debug, Serialize, Deserialize)]
pub struct ShopSiteEnabled {
    pub id: i32,
    pub enabled: i32,
}

#[post("/add_shop_site")]
pub async fn add_shop_site(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<AddShopSite>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;
    let sql = format!(
        "INSERT INTO `{}` (user_id,upload_time,alias,website,collection_team,risk_control_team,note,enabled) VALUES (?,?,?,?,?,?,?,?)",
        TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            user_id.to_string(),
            generate_database_time(),
            "",
            json.website.clone(),
            json.collection_team,
            json.risk_control_team,
            "",
            1
        ]
    );

    Ok(JsonOk("添加成功"))
}

/// 删除旧账号 删除
#[post("/delete_shop_site")]
pub async fn delete_shop_site(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_shop_site")]
pub async fn change_shop_site(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<ChangeShopSite>,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;
    //查询关系表
    let sql = format!(
        r#"
        SELECT o.id,o.website,o.collection_team,o.risk_control_team,o.note
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        "#,
        TABLE
    );

    let current_data: Option<ChangeShopSite> =
        query_data_sql_one!(state.mysql_service, &sql, [json.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("记录不存在"))?;

    let (fields_update, mut params_update) = update_data_map_createsql(&json, &current_data)?;

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(current_data.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_shop_site")]
pub async fn get_shop_site(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetShopSite>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}

#[get("/shop_site_on_enabled")]
pub async fn shop_site_on_enabled(
    state: web::Data<AppState>,
    req: HttpRequest,
    query: web::Query<ShopSiteEnabled>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let sql = format!(
        "UPDATE {} SET enabled = ? WHERE id = ? AND user_id = ?",
        TABLE
    );

    update_data_sql!(
        state.mysql_service,
        &sql,
        [query.enabled, query.id, user_id]
    );

    Ok(JsonOk("修改成功"))
}
