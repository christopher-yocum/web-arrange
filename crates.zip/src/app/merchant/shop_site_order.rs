use crate::AppState;
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, web};
use chrono::NaiveDateTime;
use serde::Serialize;
use serde_json::{Value, json};
const TABLE: &str = "shop_site_order";
const DISPLAY_FIELDS: &str = r#"id,upload_time,shopsite,odd_numbers,pay_method,sum_money,currency,order_status,consignee,email,ip_address"#;

#[derive(sqlx::FromRow, Debug, Serialize)]
struct ShopSiteOrder {
    id: i32,                    //1 id
    upload_time: NaiveDateTime, //2 下单时间
    shopsite: String,           //3 购物网站
    odd_numbers: String,        //4 网站单号
    pay_method: i32,            //5 付款方式
    sum_money: i32,             //6 金额
    currency: String,           //7 币种
    order_status: i32,          //8 订单状态
    consignee: String,          //10 收货人
    email: String,              //11 邮箱
    ip_address: String,         //12 IP地址
}

#[get("/get_shop_site_order")]
pub async fn get_shop_site_order(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<ShopSiteOrder>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}
