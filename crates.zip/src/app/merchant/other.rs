use crate::AppState;
use crate::app::receive::collection_team::TABLE as COLLECTION_TEAM_TABLE;
use crate::app::receive::risk_control_team::TABLE as RISK_CONTROL_TEAM_TABLE;
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerResult};
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, web};
use serde::Serialize;
use serde_json::{Value, json};

#[derive(sqlx::FromRow, Serialize)]
pub struct CollectionTeam {
    #[serde(rename = "label")]
    pub id: i32,
    #[serde(rename = "value")]
    pub alias: String,
}

/// 获取风控组列表
#[get("/shopsite_controlteam")]
pub async fn shopsite_controlteam(
    state: web::Data<AppState>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let sql = format!(
        "SELECT id,alias FROM `{}` where user_id = ?",
        RISK_CONTROL_TEAM_TABLE
    );

    let data = state
        .mysql_service
        .query_data_sql_all::<CollectionTeam>(&sql, &[user_id.to_string()])
        .await?;

    let total_count = data.len();

    Ok(JsonOk(json!({
        "data": data,
        "total_count": total_count
    })))
}

//收款组
#[get("/shopsite_collectionteam")]
pub async fn shopsite_collectionteam(
    state: web::Data<AppState>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let sql = format!(
        "SELECT id,alias FROM `{}` where user_id = ?",
        COLLECTION_TEAM_TABLE
    );
    let params = vec![user_id.to_string()];

    let data = state
        .mysql_service
        .query_data_sql_all::<CollectionTeam>(&sql, &params)
        .await?;
    let total_count = data.len();
    Ok(JsonOk(json!({
        "data": data,
        "total_count": total_count
    })))
}
