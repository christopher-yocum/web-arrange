macro_rules! validate_error {
    ($message:expr) => {
        let mut err = validator::ValidationError::new("");
        err.message = Some($message.into());
        return Err(err)
    };
}

pub fn validate_website(website: &str) -> Result<(), validator::ValidationError> {
    if website.is_empty() {
        validate_error!("网站不能为空");
    }
    Ok(())
}

// 小于等于0 报错
pub fn validate_collection_team(collection_team: i32) -> Result<(), validator::ValidationError> {
    if collection_team <= 0 {
        validate_error!("收款组不能为空");
    }
    Ok(())
}

pub fn validate_risk_control_team(
    risk_control_team: i32,
) -> Result<(), validator::ValidationError> {
    if risk_control_team <= 0 {
        validate_error!("风控组不能为空");
    }
    Ok(())
}
