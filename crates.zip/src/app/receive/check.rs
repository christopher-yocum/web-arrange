macro_rules! validate_error {
    ($message:expr) => {
        let mut err = validator::ValidationError::new("");
        err.message = Some($message.into());
        return Err(err)
    };
}

pub fn validate_alias(alias: &str) -> Result<(), validator::ValidationError> {
    if alias.is_empty() {
        validate_error!("别名不能为空");
    }
    Ok(())
}   