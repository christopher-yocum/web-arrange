use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::ServerError;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one};
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

const TABLE: &str = "paypal_collection";
const DISPLAY_FIELDS: &str = "id,email,payment_mode,enabled,payment_environment,payment_restriction,minimum_amount_per_transaction,maximum_amount_per_transaction,limited_payment_amount,current_collection_amount,limit_number_of_receipts,current_number_payments_received,daily_payment_plan,call_time,note,upload_time";

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Validate)]
struct AddPayPalGroup {
    email: String,
    payment_mode: i32,
    enabled: i32,
    payment_environment: i32,
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Validate)]
struct ChangePayPalGroup {
    id: i32,
    email: String,
    payment_mode: i32,
    enabled: i32,
}

#[derive(sqlx::FromRow, Debug, Serialize)]
struct GetPayPalCollection {
    id: i32,                               //1 id
    upload_time: NaiveDateTime,            //2 上传时间
    email: String,                         //3 邮箱
    payment_mode: i32,                     //5 支付方式
    enabled: i32,                          //6 是否启用
    payment_environment: i32,              //7 支付环境
    payment_restriction: i32,              //8 支付限制
    minimum_amount_per_transaction: i32,   //9 最小交易金额
    maximum_amount_per_transaction: i32,   //10 最大交易金额
    limited_payment_amount: i32,           //11 限制支付金额
    current_collection_amount: i32,        //12 当前收集金额
    limit_number_of_receipts: i32,         //13 限制收款次数
    current_number_payments_received: i32, //14 当前收款次数
    daily_payment_plan: i32,               //15 每日收款计划
    call_time: i32,                        //16 收款时间
    note: String,                          //17 备注
}

#[post("/add_paypal_group")]
pub async fn add_paypal_group(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<AddPayPalGroup>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;
    let sql = format!(
        "INSERT INTO `{}` (user_id,upload_time,email,payment_mode,enabled,payment_environment) VALUES (?,?,?,?,?,?)",
        TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            user_id.to_string(),
            generate_database_time(),
            json.email.clone(),
            json.payment_mode,
            json.enabled,
            json.payment_environment,
        ]
    );

    Ok(JsonOk("添加成功"))
}

/// 删除旧账号 删除
#[post("/delete_paypal_group")]
pub async fn delete_paypal_group(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_paypal_group")]
pub async fn change_paypal_group(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<ChangePayPalGroup>,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;
    //查询关系表
    let sql = format!(
        r#"
        SELECT o.id,o.website,o.collection_team,o.risk_control_team,o.note
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        "#,
        TABLE
    );

    let current_data: Option<ChangePayPalGroup> =
        query_data_sql_one!(state.mysql_service, &sql, [json.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("记录不存在"))?;

    let (fields_update, mut params_update) = update_data_map_createsql(&json, &current_data)?;

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(current_data.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_paypal_group")]
pub async fn get_paypal_group(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetPayPalCollection>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}
