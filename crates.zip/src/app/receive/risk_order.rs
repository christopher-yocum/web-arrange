use crate::AppState;
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, web};
use chrono::NaiveDateTime;
use serde::Serialize;
use serde_json::{Value, json};

const TABLE: &str = "risk_order";
const DISPLAY_FIELDS: &str =
    "id,upload_time,shopsite,odd_numbers,pay_method,sum_money,risk_control_reasons";

#[derive(sqlx::FromRow, Debug, Serialize)]
struct GetRiskOrder {
    id: i32,                      //1 id
    upload_time: NaiveDateTime,   //2 上传时间
    shopsite: String,             //3 购物网站
    odd_numbers: String,          //4 网站单号
    pay_method: i32,              //5 付款方式
    sum_money: i32,               //6 金额
    risk_control_reasons: String, //7 风控原因
}

#[get("/get_risk_order")]
pub async fn get_risk_order(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetRiskOrder>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}
