use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::ServerError;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one};
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

pub const TABLE: &str = "risk_control_team";
const DISPLAY_FIELDS: &str = "id,upload_time,alias,note";

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize)]
struct AddRiskGroup {
    alias: String, //3 别名
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Validate)]
struct ChangeRiskGroup {
    id: i32,
    alias: String,
    note: String,
}

#[derive(sqlx::FromRow, Debug, Serialize)]
struct GetRiskGroup {
    id: i32,                    //1 id
    upload_time: NaiveDateTime, //2 上传时间
    alias: String,              //3 别名
    note: String,               //4 备注
}

#[post("/add_risk_control_team")]
pub async fn add_risk_control_team(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<AddRiskGroup>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let sql = format!(
        "INSERT INTO `{}` (user_id,upload_time,alias,note) VALUES (?,?,?,?)",
        TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            user_id.to_string(),
            generate_database_time(),
            json.alias.clone(),
            ""
        ]
    );

    Ok(JsonOk("添加成功"))
}



/// 删除旧账号 删除
#[post("/delete_risk_control_team")]
pub async fn delete_risk_control_team(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_risk_control_team")]
pub async fn change_risk_control_team(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<ChangeRiskGroup>,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;
    //查询关系表
    let sql = format!(
        r#"
        SELECT {} FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        &DISPLAY_FIELDS, TABLE
    );

    let current_data: Option<ChangeRiskGroup> =
        query_data_sql_one!(state.mysql_service, &sql, [json.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("记录不存在"))?;

    let (fields_update, mut params_update) = update_data_map_createsql(&json, &current_data)?;

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(current_data.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}


#[get("/get_risk_control_team")]
pub async fn get_risk_control_team(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetRiskGroup>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}
