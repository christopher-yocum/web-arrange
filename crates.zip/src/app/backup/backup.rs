use crate::app::merchant::receive_payment_site::TABLE as RECEIVE_PAYMENT_SITE_TABLE;
use crate::response::{JsonOk, ServerResult};
use crate::{AppState, query_data_sql_all};
use actix_web::{get, web};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};

const WP_BACKUPS_TABLE: &str = "wp_backups";

#[derive(Debug, Deserialize, Serialize, Default, sqlx::FromRow)]
struct DeployDomainName {
    website: String,
}

#[derive(Debug, Deserialize, Serialize, Default, sqlx::FromRow)]
struct BackupDatabase {
    name: String,
    website_url: String,
    sql_url: String,
}

#[get("/get_deploy_domain_name")]
pub async fn get_deploy_domain_name(state: web::Data<AppState>) -> ServerResult<Value> {
    let sql = format!(
        r#"
        select website from {} where enabled = 1 and user_id = 1
        "#,
        RECEIVE_PAYMENT_SITE_TABLE
    );

    let data: Vec<DeployDomainName> = query_data_sql_all!(state.mysql_service, &sql, [1]);

    let total_count = data.len() as i32;

    Ok(JsonOk(json!({
        "data": data,
        "total_count": total_count
    })))
}

#[get("/get_backup_database")]
pub async fn get_backup_database(state: web::Data<AppState>) -> ServerResult<Value> {
    let sql = format!(
        r#"
        select name, website_url, sql_url from {} where enabled = 1 and user_id = 1
        "#,
        WP_BACKUPS_TABLE
    );

    let data: Vec<BackupDatabase> = query_data_sql_all!(state.mysql_service, &sql, [1]);

    let total_count = data.len() as i32;

    Ok(JsonOk(json!({
        "data": data,
        "total_count": total_count
    })))
}
