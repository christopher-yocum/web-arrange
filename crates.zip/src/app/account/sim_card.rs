use crate::app::account::check::{validate_phone, validate_phone_label};
use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::ServerError;
use crate::response::{JsonOk, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one};
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

pub const TABLE: &str = "sim_card";
const DISPLAY_FIELDS: &str = r#"id,upload_time,phone_label,phone,uses_number,belong,note"#;

#[derive(Deserialize, Debug, Serialize, Validate)]
struct AddSimCard {
    #[validate(custom(function = "validate_phone_label", code = "phone_label"))]
    phone_label: String,
    #[validate(custom(function = "validate_phone", code = "phone"))]
    phone: String,
}

#[derive(sqlx::FromRow, Deserialize, Debug, Serialize, Validate)]
pub struct ChangeSimCard {
    id: i32,
    phone_label: String,
    phone: String,
    belong: i32,
    note: String,
}

#[derive(sqlx::FromRow, Debug, Serialize)]
struct GetSimCard {
    id: i32,                    //1 主键
    upload_time: NaiveDateTime, //2 上传时间
    phone_label: String,        //3 手机编号
    phone: String,              //4 手机号
    uses_number: i32,           //5 使用次数
    belong: i32,                //6 归属
    note: String,               //7 备注
    #[sqlx(skip)]
    keyname: serde_json::Value, //8 权限组
}

#[derive(sqlx::FromRow, Debug, Serialize)]
struct UsableSimCard {
    id: i32,
    uses_number: i32,
    belong: i32,
    phone: String,
    phone_label: String,
}

#[derive(sqlx::FromRow, Debug, Serialize)]
struct Usable {
    uses_number: i32,
}

#[post("/add_simcard")]
pub async fn add_simcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    request: web::Json<AddSimCard>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    request.validate()?;
    let sql = format!(
        r#"
        INSERT INTO `{}` (user_id,upload_time,phone_label,phone,uses_number,belong,note) 
        SELECT ?, ?, ?, ?, ?, ?, ?
        FROM DUAL
        WHERE NOT EXISTS (
            SELECT 1 FROM `{}` WHERE phone = ? AND user_id = ?
        )
        "#,
        TABLE, TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            &user_id,                 //1 用户ID
            generate_database_time(), //2 上传时间
            &request.phone_label,     //3 手机编号
            &request.phone,           //4 手机号
            0,                        //5 使用次数
            &user_id,                 //6 归属
            "",                       //7 备注
            &request.phone,           //8 手机号(用于WHERE条件)
            &user_id,                 //9 用户ID(用于WHERE条件)
        ]
    );

    Ok(JsonOk("添加成功"))
}

/// 删除旧账号 删除
#[post("/delete_simcard")]
pub async fn delete_simcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    // 先判断 使用次数是否大于0
    let sql = format!(
        r#"
        SELECT uses_number FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    let result: Option<Usable> = query_data_sql_one!(state.mysql_service, &sql, [id, user_id]);

    if result
        .ok_or_else(|| anyhow!("record does not exist"))?
        .uses_number
        > 0
    {
        return Err(ServerError::OtherServerError(anyhow!(
            "使用次数大于0 不能删除"
        )));
    }

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_simcard")]
pub async fn change_simcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<ChangeSimCard>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    json.validate()?;

    //查询关系表
    let sql = format!(
        r#"
        SELECT {} FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        &DISPLAY_FIELDS, &TABLE
    );

    let current_data: Option<GetSimCard> =
        query_data_sql_one!(state.mysql_service, &sql, [json.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("record does not exist"))?;

    let (fields_update, mut params_update) = update_data_map_createsql(&json, &current_data)?;

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(current_data.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_simcard")]
pub async fn get_simcard(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetSimCard>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}

/// 获取可用的SIM卡列表
#[get("/get_usable_simcard")]
pub async fn get_usable_simcard(
    state: web::Data<AppState>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    // 获取用户ID
    let user_id = user_info.user_id;

    let usable_simcard_sql = format!(
        r#"
        SELECT uses_number,phone,phone_label,id,belong,note FROM `{}` WHERE user_id = ? AND uses_number < 4
        "#,
        TABLE
    );

    let usable_simcard_results = state
        .mysql_service
        .query_data_sql_all::<UsableSimCard>(&usable_simcard_sql, &[user_id.to_string()])
        .await?;

    Ok(JsonOk(json!({
        "data": usable_simcard_results,
        "total_count": usable_simcard_results.len() as i32
    })))
}
