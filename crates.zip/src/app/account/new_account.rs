use crate::app::account::check::{
    validate_email, validate_fullname, validate_password, validate_phone, validate_phone_label,
};
use crate::app::account::dispose::{
    ACCOUNT_ID_TABLE, delete_picture, generate_file_path, ment_i8_to_str, ment_str_to_i8,
    process_file_path, save_pictures,
};
use crate::config::setting::read_field;
use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerError, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one, update_data_sql};
use actix_multipart::Multipart;
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

use crate::app::account::sim_card::TABLE as SIM_CARD_TABLE;
const TABLE: &str = "new_account";
const DISPLAY_FIELDS: &str = r#"id,upload_time,fullname,email,password,phone_label,phone,authenticator,style,sign_up_time,file_path,source,ment,money,note"#;

#[derive(Debug, Deserialize, Serialize, Default, Validate)]
pub struct AddNewAccount {
    id: i32, //1 主键
    #[validate(custom(function = "validate_email", code = "email"))]
    email: String, //2 邮箱
    #[validate(custom(function = "validate_password", code = "password"))]
    password: String, //3 密码
    #[validate(custom(function = "validate_phone_label", code = "phone_label"))]
    phone_label: String, //4 手机编号
    #[validate(custom(function = "validate_phone", code = "phone"))]
    phone: String, //5 手机号
    authenticator: String, //6 验证器
    table: String, //7 表名
    sim_card_id: i32, //8 电话卡ID
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize)]
struct ExistData {
    fullname: String,
    file_path: String,
    sign_up_time: String,
}

#[derive(Debug, Deserialize, Serialize, Default, Validate)]
struct ChangeNewAccount {
    id: i32,               //1 主键
    fullname: String,      //2 全名 校验
    email: String,         //3 邮箱 校验
    password: String,      //4 密码 校验
    phone_label: String,   //5 手机编号 校验
    phone: String,         //6 手机号 校验
    authenticator: String, //7 验证器
    sign_up_time: String,  //8 注册时间
    file_path: String,     //9 图片路径
    note: String,          //10 备注
    #[serde(deserialize_with = "style_str_to_i8")]
    style: i8, //11 类型
    #[serde(deserialize_with = "ment_str_to_i8")]
    ment: i8, //12 状态
}

// New PayPal account
#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Default)]
struct GetNewAccount {
    id: i32,                    //1 主键
    upload_time: NaiveDateTime, //2 上传时间
    fullname: String,           //3 全名
    email: String,              //4 邮箱
    password: String,           //5 密码
    phone_label: String,        //6 手机编号
    phone: String,              //7 手机号
    sign_up_time: String,       //8 注册时间
    authenticator: String,      //9 验证器
    note: String,               //10 备注
    #[serde(serialize_with = "style_i8_to_str")]
    style: i8, //11 类型
    #[serde(serialize_with = "ment_i8_to_str")]
    ment: i8, //12 状态
    #[serde(serialize_with = "process_file_path")]
    file_path: String, //13 图片路径
}

#[derive(Debug, Deserialize, Serialize, Default, Validate)]
struct IndependenceNewAccount {
    #[validate(custom(function = "validate_fullname", code = "fullname"))]
    fullname: String, //1 全名
    #[validate(custom(function = "validate_email", code = "email"))]
    email: String, //2 邮箱
    #[validate(custom(function = "validate_password", code = "password"))]
    password: String, //3 密码
    #[validate(custom(function = "validate_phone", code = "phone"))]
    phone: String, //4 手机号
    phone_label: String,   //5 手机编号
    authenticator: String, //6 验证器
    #[serde(deserialize_with = "style_str_to_i8")]
    style: i8, //7 类型
    sign_up_time: String,  //8 注册时间
}

#[derive(sqlx::FromRow)]
struct SourceResult {
    file_path: String,
    phone_label: String,
}

#[derive(Debug, Deserialize)]
pub struct ExtractAccountDataRequest {
    id: i32,
    table: String,
}

#[derive(Debug, Serialize, sqlx::FromRow)]
struct ExtractAccountDataResponse {
    email: String,
    password: String,
    phone: String,
    authenticator: String,
    phone_label: String,
}

/// 添加新账号 通过oldaccount oldcard表 增加
#[post("/add_newaccount")]
pub async fn add_newaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    // 处理上传的图片和表单数据
    let (_, _, request) = read_field::<AddNewAccount>(multipart).await?;

    // 来源 1 注册 2 购买 3 自增
    let (table, source, account_id_field) = match request.table.as_str() {
        "oldcard" => {
            // 老证件 注册
            (
                "old_card",
                1,
                "(user_id, new_account_id, old_card_id, sim_card_id)",
            )
        }
        "oldaccount" => {
            // 老账号 购买
            (
                "old_account",
                2,
                "(user_id, new_account_id, old_account_id, sim_card_id)",
            )
        }
        _ => return Err(ServerError::OtherServerError(anyhow!("来源错误"))),
    };

    let exist_sql = format!(
        "SELECT fullname, file_path, sign_up_time FROM `{}` WHERE id = ? LIMIT 1",
        &table
    );
    let exist_data: Option<ExistData> =
        query_data_sql_one!(state.mysql_service, &exist_sql, [request.id]);

    let data = exist_data.ok_or_else(|| anyhow!("record does not exist"))?;

    let upload_time = generate_database_time();

    let add_newaccount_sql = format!(
        r#"
        INSERT INTO `{}` (
            user_id, 
            upload_time, 
            fullname, 
            file_path, 
            sign_up_time, 
            style,
            email, 
            password, 
            phone, 
            phone_label, 
            authenticator, 
            ment,
            money,
            source,
            note
        ) 
        SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        WHERE NOT EXISTS (
            SELECT 1 FROM `{}` WHERE email = ? AND user_id = ?
        )
        "#,
        &TABLE, &TABLE
    );
    let new_account_id = insert_data_sql!(
        state.mysql_service,
        &add_newaccount_sql,
        [
            &user_id,               //1 用户ID
            &upload_time,           //2 上传时间
            &data.fullname,         //3 全名
            &data.file_path,        //4 图片路径
            &data.sign_up_time,     //5 注册时间
            1,                      //6 注册类型
            &request.email,         //7 邮箱
            &request.password,      //8 密码
            &request.phone,         //9 手机号
            &request.phone_label,   //10 手机编号
            &request.authenticator, //11 验证器
            1,                      //12 状态
            0,                      //13 价格
            &source,                //14 来源
            "",                     //15 备注
            &request.email,         //16 邮箱(用于WHERE条件)
            &user_id,               //17 用户ID(用于WHERE条件)
        ]
    );

    // 更新电话卡使用次数
    let update_sql = format!(
        r#"
        UPDATE `{}` SET uses_number = uses_number + 1 WHERE phone_label = ? AND user_id = ?
        "#,
        SIM_CARD_TABLE
    );

    update_data_sql!(
        state.mysql_service,
        &update_sql,
        [&request.phone_label, &user_id]
    );

    // 更新account_id 表
    let update_account_id_sql = format!(
        r#"
        INSERT INTO `{}` {} VALUES (?, ?, ?, ?)
        "#,
        ACCOUNT_ID_TABLE, &account_id_field
    );

    update_data_sql!(
        state.mysql_service,
        &update_account_id_sql,
        [&user_id, &new_account_id, &request.id, &request.sim_card_id,]
    );

    Ok(JsonOk("添加成功"))
}

/// 删除旧账号 删除
#[post("/delete_newaccount")]
pub async fn delete_newaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    //查询关系表
    let query_sql = format!(
        r#"
        SELECT source, file_path, phone_label FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    let exist_data: Option<SourceResult> =
        query_data_sql_one!(state.mysql_service, &query_sql, [id, user_id]);

    let data = exist_data.ok_or_else(|| anyhow!("record does not exist"))?;

    //更新电话卡使用次数
    let update_sql = format!(
        r#"
        UPDATE `{}` SET uses_number = uses_number - 1 WHERE phone_label = ? AND user_id = ?
        "#,
        SIM_CARD_TABLE
    );

    update_data_sql!(
        state.mysql_service,
        &update_sql,
        [&data.phone_label, &user_id]
    );

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    delete_picture(&data.file_path).await?;

    Ok(JsonOk("删除成功"))
}

/// 修改新账号
#[post("/change_newaccount")]
pub async fn change_newaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let username = user_info.username;

    let (filename, content, request) = read_field::<ChangeNewAccount>(multipart).await?;

    //查询关系表
    let sql = format!(
        r#"
        SELECT o.file_path,o.id,o.fullname,o.email,o.password,o.phone_label,o.phone,o.authenticator,o.style,o.sign_up_time,o.ment,o.money,o.note,o.upload_time
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM `{}` a WHERE a.oldaccount_id = o.id
        )
        "#,
        TABLE, ACCOUNT_ID_TABLE
    );

    let current_data: Option<GetNewAccount> =
        query_data_sql_one!(state.mysql_service, &sql, [request.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("记录不存在"))?;

    let (mut fields_update, mut params_update) =
        update_data_map_createsql(&request, &current_data)?;

    if !filename.is_empty() {
        // 新图片 路径
        let file_path = generate_file_path(&username, &request.fullname, &filename);

        fields_update.push("file_path = ?".to_string());
        params_update.push(file_path.clone());

        // 删除旧图片 保存新图片
        save_pictures(&file_path, Some(&current_data.file_path), &content).await?;
    }

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = &format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(request.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_newaccount")]
pub async fn get_newaccount(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetNewAccount>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}

#[post("/independence_newaccount")]
pub async fn independence_newaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let username = user_info.username;

    let (filename, content, request) = read_field::<IndependenceNewAccount>(multipart).await?;

    let file_path = generate_file_path(&username, &request.fullname, &filename);
    let upload_time = generate_database_time();

    let sql = format!(
        r#"
        INSERT INTO `{}` (user_id, upload_time, fullname, email, password, phone_label, phone, authenticator, style, sign_up_time, file_path,ment,money,note,source) 
        SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        FROM DUAL
        WHERE NOT EXISTS (
            SELECT 1 FROM `{}` WHERE email = ? AND user_id = ?
        )
        "#,
        TABLE, TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            &user_id,               //1 用户ID
            &upload_time,           //2 上传时间
            &request.fullname,      //3 全名
            &request.email,         //4 邮箱
            &request.password,      //5 密码
            &request.phone_label,   //6 手机编号
            &request.phone,         //7 手机号
            &request.authenticator, //8 验证器
            &request.style,         //9 类型
            &request.sign_up_time,  //10 注册时间
            &file_path,             //11 图片路径
            1,                      //12 状态
            0,                      //13 价格
            "",                     //14 备注
            3,                      //15 自增
            &request.email,         //16 邮箱(用于WHERE条件)
            &user_id,               //17 用户ID(用于WHERE条件)
        ]
    );

    // 更新电话卡使用次数
    let update_sql = format!(
        r#"
        UPDATE `{}` SET uses_number = uses_number + 1 WHERE phone_label = ? AND user_id = ?
        "#,
        SIM_CARD_TABLE
    );

    update_data_sql!(
        state.mysql_service,
        &update_sql,
        [&request.phone_label, &user_id]
    );

    //添加图片
    save_pictures(&file_path, None, &content).await?;

    Ok(JsonOk("添加成功"))
}

#[post("/extract_account_data")]
pub async fn extract_account_data(
    state: web::Data<AppState>,
    req: HttpRequest,
    query: web::Json<ExtractAccountDataRequest>,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let table = match query.table.as_str() {
        "oldcard" => {
            // 老证件 注册
            "old_card"
        }
        "oldaccount" => {
            // 老账号 购买
            "old_account"
        }
        _ => return Err(ServerError::OtherServerError(anyhow!("来源错误"))),
    };

    let extract_sql = &format!(
        r#"
            SELECT 
                n.email,
                n.password,
                n.phone,
                n.authenticator,
                n.phone_label
            FROM account_id a
            INNER JOIN new_account n 
                ON a.new_account_id = n.id
            WHERE a.{}_id = ? AND a.user_id = ?
            LIMIT 1
            "#,
        table
    );

    let params = &[query.id.to_string(), user_id.to_string()];

    let data = state
        .mysql_service
        .query_data_sql_one::<ExtractAccountDataResponse>(extract_sql, params)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count": 1
    })))
}

fn style_i8_to_str<S>(value: &i8, serializer: S) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    // 直接将数字转为字符串
    serializer.serialize_str(&value.to_string())
}

fn style_str_to_i8<'de, D>(deserializer: D) -> Result<i8, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let s = String::deserialize(deserializer)?;
    match s.parse::<i8>() {
        Ok(value) => Ok(value),
        Err(_) => Ok(0), // 解析失败时返回默认值
    }
}
