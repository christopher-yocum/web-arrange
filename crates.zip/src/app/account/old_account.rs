use crate::app::account::check::{
    validate_email, validate_fullname, validate_password, validate_sign_up_time,
};
use crate::app::account::dispose::DeleteFilePath;
use crate::app::account::dispose::{
    ACCOUNT_ID_TABLE, delete_picture, generate_file_path, ment_i8_to_str, ment_str_to_i8,
    process_file_path, save_pictures,
};
use crate::config::setting::read_field;
use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerError, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_all, query_data_sql_one};
use actix_multipart::Multipart;
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

const TABLE: &str = "old_account";
const DISPLAY_FIELDS: &str = r#"id,upload_time,fullname,old_email,old_password,old_phone,file_path,sign_up_time,money,note,ment"#;
/// 增加旧账户元数据
#[derive(Deserialize, Debug, Default, Serialize, Validate)]
pub struct AddOldAccount {
    #[validate(custom(function = "validate_fullname", code = "fullname"))]
    fullname: String, //1 全名
    #[validate(custom(function = "validate_email", code = "email"))]
    old_email: String, //2 邮箱
    #[validate(custom(function = "validate_password", code = "password"))]
    old_password: String, //3 密码
    old_phone: String, //4 电话
    #[validate(custom(function = "validate_sign_up_time", code = "sign_up_time"))]
    sign_up_time: String, //5 注册时间
    #[serde(skip_deserializing)]
    money: i32, //6 价格
}

/// 修改旧账户请求
#[derive(Deserialize, Serialize, Debug, Default, Validate)]
struct ChangeOldAccount {
    id: i32,              //1 主键
    fullname: String,     //2 全名
    old_email: String,    //3 邮箱
    old_password: String, //4 密码
    old_phone: String,    //5 电话
    sign_up_time: String, //6 注册时间
    note: String,         //7 备注
    #[serde(deserialize_with = "ment_str_to_i8")]
    ment: i8, //8 状态
    #[serde(skip_deserializing)]
    money: i32, //9 价格
}

#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Default, Validate)]
struct GetOldAccount {
    id: i32,                    //1
    upload_time: NaiveDateTime, //2
    fullname: String,           //3
    old_email: String,          //4
    old_password: String,       //5
    old_phone: String,          //6
    sign_up_time: String,       //7
    money: i32,                 //8
    note: String,               //9
    #[serde(serialize_with = "ment_i8_to_str")]
    ment: i8, //10
    #[serde(serialize_with = "process_file_path")]
    file_path: String, //11
}

#[derive(Debug, sqlx::FromRow, Serialize, Deserialize, Clone)]
struct DeleteOldcardResult {
    file_path: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct VagueOldAccount {
    email: String,
}

/// 添加旧账号 增加
#[post("/add_oldaccount")]
pub async fn add_oldaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let role = user_info.role;
    let username = user_info.username;
    // 处理上传的图片和表单数据
    let (filename, content, mut request) = read_field::<AddOldAccount>(multipart).await?;

    // money 价格
    request.money = validate_price(&request.sign_up_time)?;

    // 生成图片地址
    let file_path = generate_file_path(&username, &request.fullname, &filename);
    let upload_time = generate_database_time();

    println!("{:?}", request);
    println!("{:?}", &file_path);
    println!("{:?}", upload_time);

    let sql = format!(
        r#"
        INSERT INTO `{}` (user_id, fullname, old_email, old_password, old_phone, sign_up_time, money, file_path, upload_time, note, ment, belong) 
        SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        WHERE NOT EXISTS (
            SELECT 1 FROM `{}` WHERE old_email = ?
        )
        "#,
        TABLE, TABLE
    );

    insert_data_sql!(
        state.mysql_service,
        &sql,
        [
            user_id,
            request.fullname,
            &request.old_email,
            request.old_password,
            request.old_phone,
            request.sign_up_time,
            request.money,
            &file_path,
            upload_time,
            "",
            8,
            role,
            &request.old_email,
        ]
    );

    //添加图片
    save_pictures(&file_path, None, &content).await?;

    Ok(JsonOk("添加成功"))
}

/// 获取年份 价格
fn validate_price(year: &str) -> anyhow::Result<i32> {
    if year.is_empty() {
        anyhow::bail!("Year cannot be empty");
    }

    // 匹配年份 返回价格
    match year {
        "2018" => Ok(650),
        "2019" => Ok(550),
        "2020" => Ok(450),
        "2021" => Ok(450),
        "2022" => Ok(450),
        "2023" => Ok(400),
        "2024" => Ok(350),
        _ => anyhow::bail!("Invalid year"),
    }
}

/// 删除旧账号 删除
#[post("/delete_oldaccount")]
pub async fn delete_oldaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    //查询关系表
    let query_sql = format!(
        r#"
        SELECT o.file_path
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM `{}` a WHERE a.old_account_id = o.id
        )
        "#,
        TABLE, ACCOUNT_ID_TABLE
    );

    let exist_data: Option<DeleteFilePath> =
        query_data_sql_one!(state.mysql_service, &query_sql, [id, user_id]);

    let data = exist_data.ok_or_else(|| anyhow!("record does not exist"))?;

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    delete_picture(&data.file_path).await?;

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_oldaccount")]
pub async fn change_oldaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let username = user_info.username;

    let (filename, content, mut request) = read_field::<ChangeOldAccount>(multipart).await?;

    //查询关系表
    let sql = format!(
        r#"
        SELECT o.file_path,o.id,o.fullname,o.old_email,o.old_password,o.old_phone,o.sign_up_time,o.money,o.note,o.ment,o.upload_time
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM `{}` a WHERE a.oldaccount_id = o.id
        )
        "#,
        TABLE, ACCOUNT_ID_TABLE
    );

    let current_data: Option<GetOldAccount> =
        query_data_sql_one!(state.mysql_service, &sql, [request.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("record does not exist"))?;

    // money 价格
    request.money = validate_price(&request.sign_up_time)?;

    let (mut fields_update, mut params_update) =
        update_data_map_createsql(&request, &current_data)?;

    if !filename.is_empty() {
        // 新图片 路径
        let file_path = generate_file_path(&username, &request.fullname, &filename);

        fields_update.push("file_path = ?".to_string());
        params_update.push(file_path.clone());

        // 删除旧图片 保存新图片
        save_pictures(&file_path, Some(&current_data.file_path), &content).await?;
    }

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(request.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_oldaccount")]
pub async fn get_oldaccount(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetOldAccount>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}

/// 获取旧账号列表 模糊查询
#[post("/get_vague_oldaccount")]
pub async fn get_vague_oldaccount(
    state: web::Data<AppState>,
    req: HttpRequest,
    query: web::Json<VagueOldAccount>,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let sql = format!(
        r#"
        SELECT * FROM `{}` WHERE old_email LIKE ? AND user_id = ?
        "#,
        TABLE
    );

    let data: Vec<GetOldAccount> = query_data_sql_all!(
        state.mysql_service,
        &sql,
        [format!("%{}%", query.email), user_id,]
    );

    let total_count = data.len() as i32;

    Ok(JsonOk(json!({
        "data": data,
        "total_count": total_count
    })))
}
