use crate::app::account::check::{validate_fullname, validate_ssn};
use crate::app::account::dispose::DeleteFilePath;
use crate::app::account::dispose::{
    ACCOUNT_ID_TABLE, delete_picture, generate_file_path, process_file_path, save_pictures,
};
use crate::config::setting::read_field;
use crate::config::setting::{DeleteRequest, generate_database_time, update_data_map_createsql};
use crate::middleware::authentication::UserInfo;
use crate::response::{JsonOk, ServerError, ServerResult};
use crate::tool::mysql_tool::QueryRequest;
use crate::{AppState, delete_data_sql, insert_data_sql, query_data_sql_one};
use actix_multipart::Multipart;
use actix_web::HttpMessage;
use actix_web::{HttpRequest, get, post, web};
use anyhow::anyhow;
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use validator::Validate;

const TABLE: &str = "old_card";
const DISPLAY_FIELDS: &str = r#"id,upload_time,fullname,ssn,file_path,belong,note"#;

#[derive(Debug, Deserialize, Serialize, Default, Validate)]
struct AddOldCard {
    #[validate(custom(function = "validate_fullname"))]
    pub fullname: String,
    #[validate(custom(function = "validate_ssn"))]
    pub ssn: String,
}

#[derive(Debug, Deserialize, Serialize, Default, Validate)]
struct ChangeOldCard {
    id: i32,
    fullname: String,
    ssn: String,
}

// Old card
#[derive(sqlx::FromRow, Debug, Serialize, Deserialize, Default)]
struct GetOldCard {
    id: i32,                    //1
    upload_time: NaiveDateTime, //2
    fullname: String,           //3
    ssn: String,                //4
    belong: i32,                //5
    note: String,               //6
    #[sqlx(skip)]
    keyname: serde_json::Value, //7
    #[serde(serialize_with = "process_file_path")]
    file_path: String, //8
}

/// 增加旧证件
#[post("/add_oldcard")]
pub async fn add_oldcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let username = user_info.username;

    let (filename, content, request) = read_field::<AddOldCard>(multipart).await?;

    let file_path = generate_file_path(&username, &request.fullname, &filename);

    let add_oldcard_sql = format!(
        r#"
        INSERT INTO `{}` (user_id,upload_time,fullname,ssn, file_path, belong, note) 
        SELECT ?, ?, ?, ?, ?, ?,?
        WHERE NOT EXISTS (
            SELECT 1 FROM `{}` WHERE fullname = ?
        )
        "#,
        TABLE, TABLE
    );

    let result = insert_data_sql!(
        state.mysql_service,
        &add_oldcard_sql,
        [
            &user_id,                 //1 用户ID
            generate_database_time(), //2 上传时间
            &request.fullname,        //3 全名
            &request.ssn,             //4 身份证号
            &file_path,               //5 图片路径
            &user_id,                 //6 用户ID
            "",                       //7 备注
            &request.fullname,        //8 全名(where校验)
        ]
    );
    if result == 0 {
        return Err(ServerError::PopUpWindowError("添加失败".to_string()));
    }

    save_pictures(&file_path, None, &content).await?;

    Ok(JsonOk("添加成功"))
}

/// 删除旧账号 删除
#[post("/delete_oldcard")]
pub async fn delete_oldcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    json: web::Json<serde_json::Value>,
) -> ServerResult<&'static str> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;

    let ids: DeleteRequest = serde_json::from_value(json.0)?;
    let id = ids.ids[0];

    //查询关系表
    let query_sql = format!(
        r#"
        SELECT o.file_path
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        AND NOT EXISTS (
            SELECT 1 FROM `{}` a WHERE a.oldaccount_id = o.id
        )
        "#,
        TABLE, ACCOUNT_ID_TABLE
    );

    let exist_data: Option<DeleteFilePath> =
        query_data_sql_one!(state.mysql_service, &query_sql, [id, user_id]);

    let data = exist_data.ok_or_else(|| anyhow!("record does not exist"))?;

    let delete_sql = format!(
        r#"
        DELETE FROM `{}` WHERE id = ? AND user_id = ?
        "#,
        TABLE
    );

    delete_data_sql!(state.mysql_service, &delete_sql, [id, user_id]);

    delete_picture(&data.file_path).await?;

    Ok(JsonOk("删除成功"))
}

/// 修改旧账号 更新
#[post("/change_oldcard")]
pub async fn change_oldcard(
    state: web::Data<AppState>,
    req: HttpRequest,
    multipart: Multipart,
) -> ServerResult<&'static str> {
    // 获取当前用户ID
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();
    let user_id = user_info.user_id;
    let username = user_info.username;

    let (filename, content, request) = read_field::<ChangeOldCard>(multipart).await?;

    //查询关系表
    let sql = format!(
        r#"
        SELECT o.file_path,o.id,o.fullname,o.ssn,o.belong,o.note,o.user_id,o.upload_time
        FROM `{}` o
        WHERE o.id = ? AND o.user_id = ?
        "#,
        TABLE
    );

    let current_data: Option<GetOldCard> =
        query_data_sql_one!(state.mysql_service, &sql, [request.id, user_id]);

    let current_data = current_data.ok_or_else(|| anyhow!("record does not exist"))?;

    let (mut fields_update, mut params_update) =
        update_data_map_createsql(&request, &current_data)?;

    if !filename.is_empty() {
        // 新图片 路径
        let file_path = generate_file_path(&username, &request.fullname, &filename);

        fields_update.push("file_path = ?".to_string());
        params_update.push(file_path.clone());

        // 删除旧图片 保存新图片
        save_pictures(&file_path, Some(&current_data.file_path), &content).await?;
    }

    // 如果 没有需要更新的字段 则返回
    if params_update.is_empty() {
        return Err(ServerError::OtherServerError(anyhow!(
            "No modified content"
        )));
    }

    // 生成更新SQL
    let update_sql = format!(
        "UPDATE `{}` SET {} WHERE id = ? AND user_id = ?",
        TABLE,
        fields_update.join(", ")
    );

    params_update.push(request.id.to_string());
    params_update.push(user_id.to_string());

    state
        .mysql_service
        .update_data_sql(&update_sql, &params_update)
        .await?;

    Ok(JsonOk("修改成功"))
}

#[get("/get_oldcard")]
pub async fn get_oldcard(
    state: web::Data<AppState>,
    query: web::Query<QueryRequest>,
    req: HttpRequest,
) -> ServerResult<Value> {
    let user_info = req.extensions().get::<UserInfo>().unwrap().clone();

    let (total_count, data) = state
        .mysql_service
        .page_query_total_sql::<GetOldCard>(&TABLE, &DISPLAY_FIELDS, &query, &user_info)
        .await?;

    Ok(JsonOk(json!({
        "data":data,
        "total_count":total_count
    })))
}
