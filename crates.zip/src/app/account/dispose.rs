use crate::response::ImageOk;
use crate::response::ServerError;
use actix_web::{get, web::Query};
use serde::Deserialize;
use serde::Serialize;
use serde::Serializer;
use std::path::Path as StdPath;
pub const ACCOUNT_ID_TABLE: &str = "account_id";

/// 图片 URL 前缀
const PICTURE_URL_PREFIX: &str = "https://wsuuus.info/v1/get_picture?img_path=";
/// 账号图片上传路径
pub const UPLOADS_ACCOUNT_PATH: &str = "./static/uploads/account";

#[derive(Deserialize)]
pub struct PictureResponse {
    pub img_path: String,
}

#[derive(Debug, sqlx::FromRow, Serialize, Deserialize)]
pub struct DeleteFilePath {
    pub file_path: String,
}

pub fn ment_i8_to_str<S>(value: &i8, serializer: S) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    // 直接将数字转为字符串
    serializer.serialize_str(&value.to_string())
}

pub fn ment_str_to_i8<'de, D>(deserializer: D) -> Result<i8, D::Error>
where
    D: serde::Deserializer<'de>,
{
    let s = String::deserialize(deserializer)?;
    match s.parse::<i8>() {
        Ok(value) => Ok(value),
        Err(_) => Ok(0), // 解析失败时返回默认值
    }
}


/// 处理文件路径
///
/// # 参数
/// * `value` - 文件路径
/// * `serializer` - 序列化器
///
/// # 返回值
/// * `Result<S::Ok, S::Error>` - 结果
pub fn process_file_path<S>(value: &String, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let value = format!("{}{}", PICTURE_URL_PREFIX, value);
    serializer.serialize_str(&value)
}

/// 文件名处理
///
/// # 参数
/// * `username` - 用户名
/// * `fullname` - 全名
/// * `image_filename` - 图片文件名
///
/// # 返回值
pub fn generate_file_path(
    username: &str,       // 用户名
    fullname: &str,       // 全名
    image_filename: &str, // 图片文件名
) -> String {
    //处理名字的空格 替换成_
    let fullname = fullname.replace(" ", "_");
    // 获取文件扩展名
    let extension = image_filename.rsplit('.').next().unwrap();
    let file_path = format!("{}_{}.{}", &username, &fullname, &extension,);
    // 返回处理后的文件路径
    file_path
}

/// 保存图片
///
/// # 参数
/// * `path` - 图片路径
/// * `delete_path` - 删除图片路径
/// * `content` - 图片内容
///
/// # 返回值
pub async fn save_pictures(
    path: &str,
    delete_path: Option<&str>,
    content: &[u8],
) -> anyhow::Result<bool> {
    // 构建路径
    let image_path = StdPath::new(UPLOADS_ACCOUNT_PATH);
    let target_file = image_path.join(path);

    // 确保父目录存在
    if let Some(parent) = target_file.parent() {
        if !parent.exists() {
            tokio::fs::create_dir_all(parent).await?;
        }
    }

    // 如果需要删除旧图片
    if let Some(path) = delete_path {
        if !path.is_empty() {
            // 删除原始图片
            let source_file = image_path.join(path);
            if source_file.exists() {
                tokio::fs::remove_file(&source_file).await?;
            }
        }
    }

    // 写入新图片
    tokio::fs::write(&target_file, content).await?;

    // 返回成功
    Ok(true)
}

/// 删除图片文件
pub async fn delete_picture(path: &str) -> anyhow::Result<()> {
    // 构建原始图片路径
    let source_path = StdPath::new(UPLOADS_ACCOUNT_PATH);
    let source_file = source_path.join(path);

    // 只删除原始图片文件
    if source_file.exists() {
        tokio::fs::remove_file(&source_file).await?;
    }
    Ok(())
}

/// 获取图片 api 接口
///
/// # 参数
/// * `request` - 请求参数
///
/// # 返回值
/// * `Result<ImageOk, ServerError>` - 结果
#[get("/get_picture")]
pub async fn get_picture(request: Query<PictureResponse>) -> Result<ImageOk, ServerError> {
    let picture = request.img_path.clone();
    let original_path = format!("{}/{}", UPLOADS_ACCOUNT_PATH, picture);

    // 异步检查文件是否存在
    tokio::fs::metadata(&original_path)
        .await
        .map_err(anyhow::Error::msg)?;

    // 异步读取文件内容
    let context = tokio::fs::read(&original_path)
        .await
        .map_err(anyhow::Error::msg)?;

    Ok(ImageOk(context))
}
