macro_rules! validate_error {
    ($message:expr) => {
        let mut err = validator::ValidationError::new("");
        err.message = Some($message.into());
        return Err(err)
    };
}

pub fn validate_fullname(fullname: &str) -> Result<(), validator::ValidationError> {
    if fullname.is_empty() {
        validate_error!("全名不能为空");
    }
    Ok(())
}

pub fn validate_email(email: &str) -> Result<(), validator::ValidationError> {
    // 判断是否为空或没有 @ 符号
    if email.is_empty() || !email.contains("@") {
        validate_error!("Email format incorrect or empty");
    }
    Ok(())
}

pub fn validate_password(password: &str) -> Result<(), validator::ValidationError> {
    if password.is_empty() {
        validate_error!("密码不能为空");
    }
    Ok(())
}

pub fn validate_phone(phone: &str) -> Result<(), validator::ValidationError> {
    if phone.is_empty() {
        validate_error!("电话不能为空");
    }
    Ok(())
}

pub fn validate_sign_up_time(sign_up_time: &str) -> Result<(), validator::ValidationError> {
    if sign_up_time.is_empty() {
        validate_error!("注册时间不能为空");
    }
    Ok(())
}

pub fn validate_ssn(ssn: &str) -> Result<(), validator::ValidationError> {
    if ssn.is_empty() {
        validate_error!("ssn不能为空");
    }
    Ok(())
}

pub fn validate_phone_label(phone_label: &str) -> Result<(), validator::ValidationError> {
    if phone_label.is_empty() {
        validate_error!("手机编号不能为空");
    }
    Ok(())
}
