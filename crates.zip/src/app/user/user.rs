use crate::app::user::power::Layout;
use crate::app::user::power::get_layout;
use crate::config::setting::generate_10_timestamp;
use crate::response::ServerError;
use crate::{AppState, query_data_sql_one};
use actix_web::HttpRequest;
use actix_web::HttpResponse;
use actix_web::body::EitherBody;
use actix_web::{Responder, get, web};
use actix_web_validator::Query;
use anyhow::anyhow;
use bcrypt::verify;
use once_cell::sync::Lazy;
use rand::Rng;
use rand::rngs::OsRng;
use regex::Regex;
use serde::Deserialize;
use serde::Serialize;
use serde_json::json;
use validator::Validate;

pub const TABLE: &str = "user_info";
static PASSWORD_REGEX: Lazy<Regex> = Lazy::new(|| Regex::new(r"^[A-Za-z\d]{5,10}$").unwrap());

#[derive(Debug, Deserialize, Validate)]
struct LoginForm {
    #[validate(custom(function = "validate_username", code = "username"))]
    username: String,
    #[validate(custom(function = "validate_password", code = "password"))]
    password: String,
}

macro_rules! validate_error {
    ($message:expr) => {
        let mut err = validator::ValidationError::new("");
        err.message = Some($message.into());
        return Err(err)
    };
}

fn validate_username(username: &str) -> Result<(), validator::ValidationError> {
    //长度
    if username.len() < 5 || username.len() > 10 {
        validate_error!("用户名长度必须在5到10之间");
    }
    //不能为空
    if username.is_empty() {
        validate_error!("用户名不能为空");
    }
    //只能包含字母和数字
    if !username.chars().all(|c| c.is_alphanumeric()) {
        validate_error!("用户名只能包含字母和数字");
    }
    Ok(())
}

fn validate_password(password: &str) -> Result<(), validator::ValidationError> {
    //长度
    if password.len() < 5 || password.len() > 10 {
        validate_error!("密码长度必须在5到10之间");
    }
    //不能为空
    if password.is_empty() {
        validate_error!("密码不能为空");
    }
    //只能包含字母和数字
    if !PASSWORD_REGEX.is_match(password) {
        validate_error!("密码必须包含字母和数字");
    }
    Ok(())
}

#[derive(Debug, sqlx::FromRow, Clone)]
struct LoginUserInfo {
    user_id: i32,
    username: String,
    password_hash: String,
    role: i32,
    //pub nickname: String,
    //pub layout: serde_json::Value,
}

#[derive(Debug, Serialize)]
struct LoginOk<T> {
    role: i32,
    token: String,
    layout: T,
}

impl<T: Serialize> Responder for LoginOk<T> {
    type Body = EitherBody<String>;
    fn respond_to(self, _: &HttpRequest) -> HttpResponse<Self::Body> {
        HttpResponse::Ok()
            .append_header(("xauthtoken", self.token.clone()))
            .json(json!({
                "code":200,
                "data":{
                    "role":self.role,
                    "token":self.token,
                    "layout":self.layout
                },
                "message":"ok",
            }))
            .map_into_right_body()
    }
}

#[get("/login")]
pub async fn login(
    state: web::Data<AppState>,
    form: Query<LoginForm>,
) -> Result<LoginOk<Layout>, ServerError> {
    let sql = format!(
        r#"SELECT u.user_id, u.nickname, u.username, u.password_hash, u.role, p.layout 
    FROM `{}` u 
    LEFT JOIN `permission` p ON u.role = p.role
    WHERE u.username = ?"#,
        TABLE
    );

    let user: Option<LoginUserInfo> =
        query_data_sql_one!(state.mysql_service, &sql, [&form.username]);

    let user = user.ok_or_else(|| anyhow!("user does not exist"))?;

    let verify_result = verify(&form.password, &user.password_hash).map_err(anyhow::Error::msg)?;

    if !verify_result {
        return Err(ServerError::LoginServerError("password error".to_owned()));
    }

    // 判断是否为管理员 如果是管理员 则返回1 否则返回-1
    let role = if user.role == 3306 { 1 } else { -1 };
    let layout = get_layout();

    // 生成token
    let mut rng = OsRng;
    // 生成16位随机字符串 不能有特殊字符
    let token_suffix: String = (0..16)
        .map(|_| {
            let n = rng.gen_range(0..62);
            match n {
                0..=9 => (b'0' + n) as char,
                10..=35 => (b'a' + (n - 10)) as char,
                _ => (b'A' + (n - 36)) as char,
            }
        })
        .collect();

    let token = format!("{} {}_{}", user.username, user.username, token_suffix);

    let data = serde_json::json!({
        "user_id": user.user_id,
        "username": user.username,
        "role": user.role,
        "created_time": generate_10_timestamp(),
        "status": "active",
        "token": token,
    });

    state
        .redis_pool
        .set(
            &format!("user:{}", user.username),
            &data.to_string(),
            60 * 60 * 24 * 30,
        )
        .await?;

    Ok(LoginOk {
        role,
        token,
        layout,
    })
}
