/// 权限管理
use serde::Serialize;

#[derive(Debug, Serialize)]
pub struct MenuItem {
    id: u8,
    auth_name: String,
    path: String,
    children: Option<Vec<MenuItem>>,
}

#[derive(Debug, Serialize)]
pub struct Layout {
    list: Vec<String>,
    version: String,
    data: Vec<MenuItem>,
}

pub fn get_layout() -> Layout {
    Layout {
        list: vec![
            "Accountmanage".to_string(),
            "Paymentmanage".to_string(),
            "Websitedeploy".to_string(),
            "ProductLibraryInfo".to_string(),
            "Emailmanage".to_string(),
            "Logmanage".to_string(),
            "Usermanage".to_string(),
        ],
        version: "v1".to_string(),
        data: vec![
            MenuItem {
                id: 1,
                auth_name: "账号管理".to_string(),
                path: "Accountmanage".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "New PayPal".to_string(),
                        path: "newaccount".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "Old PayPal".to_string(),
                        path: "oldaccount".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 3,
                        auth_name: "Old Card".to_string(),
                        path: "oldcard".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 4,
                        auth_name: "Sim Card".to_string(),
                        path: "simcard".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 2,
                auth_name: "商户管理".to_string(),
                path: "Paymentmanage".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "购物网站".to_string(),
                        path: "shop_site".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "收款网站".to_string(),
                        path: "receive_payment_site".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 3,
                        auth_name: "订单管理".to_string(),
                        path: "shop_site_order".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 3,
                auth_name: "收款管理".to_string(),
                path: "Websitedeploy".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "PayPal管理".to_string(),
                        path: "paypal_group".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "收款组".to_string(),
                        path: "collection_team".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 3,
                        auth_name: "风控组".to_string(),
                        path: "risk_control_team".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 4,
                        auth_name: "风控订单".to_string(),
                        path: "risk_order".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 4,
                auth_name: "产品库管理".to_string(),
                path: "ProductLibraryInfo".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "产品分类".to_string(),
                        path: "product_category".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "产品采集".to_string(),
                        path: "product_collection".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 5,
                auth_name: "服务器管理".to_string(),
                path: "server_manage".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "服务器列表".to_string(),
                        path: "server_list".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "服务器配置".to_string(),
                        path: "server_config".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 3,
                        auth_name: "八大政策".to_string(),
                        path: "eight_policies".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 4,
                        auth_name: "任务管理".to_string(),
                        path: "task_manage".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 6,
                auth_name: "邮箱管理".to_string(),
                path: "Emailmanage".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "邮件列表".to_string(),
                        path: "email_list".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "邮件信息".to_string(),
                        path: "email_info".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 7,
                auth_name: "日志管理".to_string(),
                path: "Logmanage".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "商户日志".to_string(),
                        path: "merchant_log".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "风控日志".to_string(),
                        path: "risk_log".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 3,
                        auth_name: "任务日志".to_string(),
                        path: "task_log".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 4,
                        auth_name: "系统日志".to_string(),
                        path: "system_log".to_string(),
                        children: None,
                    },
                ]),
            },
            MenuItem {
                id: 8,
                auth_name: "系统配置".to_string(),
                path: "system_config".to_string(),
                children: Some(vec![
                    MenuItem {
                        id: 1,
                        auth_name: "邮件通知".to_string(),
                        path: "email_notification".to_string(),
                        children: None,
                    },
                    MenuItem {
                        id: 2,
                        auth_name: "个人配置".to_string(),
                        path: "personal_config".to_string(),
                        children: None,
                    },
                ]),
            },
        ],
    }
}
