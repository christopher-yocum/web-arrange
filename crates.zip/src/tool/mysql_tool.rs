use crate::middleware::authentication::UserInfo;
use serde::Deserialize;
use sqlx::mysql::MySqlRow;
use sqlx::{FromRow, MySqlPool};
use tracing::error;
/// 查询请求
#[derive(Deserialize)]
pub struct QueryRequest {
    pub page_size: i32, // 每页显示的数量
    pub addpage: i32,   // 当前页码
    pub addjumpto: i32, // 要跳转到的页码
}
#[derive(thiserror::Error, Debug)]
pub enum MySqlError {
    #[error(transparent)]
    InlineError(#[from] sqlx::Error),

    #[error(transparent)]
    OtherError(#[from] anyhow::Error),
}

pub type MySqlResult<T> = Result<T, MySqlError>;

#[macro_export]
macro_rules! query_data_sql_all {
    ($service:expr,$sql:expr,[$($params:expr),*$(,)?]) => {
        {
            sqlx::query_as($sql)
            $(
                .bind($params)
            )*
            .fetch_all(&$service.pool).await?
        }
    };
}

pub struct MysqlService {
    pub pool: MySqlPool,
}

impl MysqlService {
    pub fn new(pool: MySqlPool) -> Self {
        Self { pool }
    }

    #[allow(dead_code)]
    pub async fn query_data_sql_one<T>(
        &self,
        sql: &str,
        params: &[String],
    ) -> MySqlResult<Option<T>>
    where
        T: for<'r> FromRow<'r, MySqlRow> + Send + Unpin,
    {
        let mut query_builder = sqlx::query_as(sql);
        for param in params {
            query_builder = query_builder.bind(param);
        }
        Ok(query_builder.fetch_optional(&self.pool).await?)
    }

    /// 分页查询 总数
    ///
    /// # Arguments
    ///
    /// * `table` - 表名
    /// * `where_clause` - 查询条件
    /// * `display_fields_str` - 显示字段
    /// * `query` - 分页查询参数
    /// * `user_info` - 用户信息
    ///
    /// # Returns
    ///
    /// * `Ok((i32, Vec<T>))` - 总数和数据
    pub async fn page_query_total_sql<T>(
        &self,
        table: &str,
        display_fields_str: &str,
        query: &QueryRequest,
        user_info: &UserInfo,
    ) -> MySqlResult<(i32, Vec<T>)>
    where
        T: for<'r> FromRow<'r, MySqlRow> + Send + Unpin,
    {
        // 使用 addjumpto 计算偏移量
        let target_page = if query.addjumpto > 0 {
            query.addjumpto
        } else {
            query.addpage
        };
        if target_page < 1 {
            error!("页码错误: page={}", target_page);
            return Err(anyhow::anyhow!("页码必须大于0").into());
        }

        let offset = (target_page - 1) * query.page_size;
        if offset < 0 {
            error!(
                "偏移量计算错误: page={}, page_size={}, offset={}",
                target_page, query.page_size, offset
            );
            return Err(anyhow::anyhow!("偏移量计算错误").into());
        }

        let where_clause = match table {
            "oldaccount" => {
                // 10001 是ph 员工的标识
                // 10002 是会员
                if user_info.role == 10002 {
                    format!(
                        "where user_id = {} OR belong = {}",
                        user_info.user_id, 10001
                    )
                } else {
                    format!("where user_id = {}", user_info.user_id)
                }
            }
            _ => {
                format!("where user_id = {}", user_info.user_id)
            }
        };

        // 获取总数
        let count_sql = format!("SELECT COUNT(1) FROM `{}` {}", table, where_clause);

        let total_count: i32 = sqlx::query_scalar(&count_sql).fetch_one(&self.pool).await?;

        // 获取分页数据
        let sql = format!(
            "SELECT {} FROM `{}` {} ORDER BY upload_time DESC LIMIT ? OFFSET ?",
            display_fields_str, table, where_clause
        );

        let results: Vec<T> = query_data_sql_all!(self, &sql, [query.page_size, offset]);

        Ok((total_count, results))
    }

    /// 查询数据
    ///
    /// # Arguments
    ///
    /// * `sql` - 查询数据的sql语句
    /// * `params` - 查询数据的参数
    ///
    /// # Returns
    ///
    /// * `Ok(Vec<T>)` - 查询数据
    pub async fn query_data_sql_all<T>(&self, sql: &str, params: &[String]) -> MySqlResult<Vec<T>>
    where
        T: for<'r> FromRow<'r, MySqlRow> + Send + Unpin,
    {
        let mut query_builder = sqlx::query_as(sql);
        for param in params {
            query_builder = query_builder.bind(param);
        }
        let rows = query_builder.fetch_all(&self.pool).await?;
        Ok(rows)
    }

    /// 插入数据
    ///
    /// # Arguments
    ///
    /// * `sql` - 插入数据的sql语句
    /// * `params` - 插入数据的参数
    ///
    /// # Returns
    ///
    /// * `Ok(i32)` - 插入成功
    /// * `Err(Box<dyn Error>)` - 插入过程中的错误
    #[allow(dead_code)]
    pub async fn insert_data_sql(&self, sql: &str, params: &[String]) -> MySqlResult<i32> {
        let mut query_builder = sqlx::query(sql);
        for param in params {
            query_builder = query_builder.bind(param);
        }

        let result = query_builder.execute(&self.pool).await?;
        // 获取插入的id
        let id: u64 = result.last_insert_id();
        Ok(id as i32)
    }

    /// 删除数据
    ///
    /// # Arguments
    ///
    /// * `sql` - 删除数据的sql语句
    /// * `params` - 删除数据的参数
    ///
    /// # Returns
    ///
    /// * `Ok(())` - 删除成功
    /// * `Err(Box<dyn Error>)` - 删除过程中的错误
    #[allow(dead_code)]
    pub async fn delete_data_sql(&self, sql: &str, params: &[String]) -> MySqlResult<i64> {
        let mut query_builder = sqlx::query(&sql);
        for param in params {
            query_builder = query_builder.bind(param);
        }

        let result = query_builder.execute(&self.pool).await?;
        if result.rows_affected() == 0 {
            return Ok(0);
        }

        let rows_affected = result.rows_affected();
        Ok(rows_affected as i64)
    }
    /// 更新数据
    ///
    /// # Arguments
    ///
    /// * `sql` - 更新数据的sql语句
    /// * `params` - 更新数据的参数
    ///
    /// # Returns
    ///
    /// * `Ok(())` - 更新成功
    pub async fn update_data_sql(&self, sql: &str, params: &[String]) -> MySqlResult<i64> {
        let mut query_builder = sqlx::query(&sql);
        for param in params {
            query_builder = query_builder.bind(param);
        }
        let result = query_builder.execute(&self.pool).await?;
        if result.rows_affected() == 0 {
            return Err(anyhow::anyhow!("更新失败").into());
        }

        Ok(result.rows_affected() as i64)
    }
}

#[macro_export]
macro_rules! query_data_sql_one {
    ($service:expr,$sql:expr,[$($params:expr),*$(,)?]) => {
        {
            sqlx::query_as($sql)
            $(
                .bind($params)
            )*
            .fetch_optional(&$service.pool).await?
        }
    };
}

/// return last id
#[macro_export]
macro_rules! insert_data_sql {
    ($service:expr,$sql:expr,[$($params:expr),*$(,)?]) => {
        {
            let result=sqlx::query($sql)
            $(
                .bind($params)
            )*
            .execute(&$service.pool).await?;
            result.last_insert_id()
        }
    };
}

#[macro_export]
macro_rules! delete_data_sql {
    ($service:expr,$sql:expr,[$($params:expr),*$(,)?]) => {
        {
            let result=sqlx::query($sql)
            $(
                .bind($params)
            )*
            .execute(&$service.pool).await?;
            result.rows_affected()
        }
    };
}

#[macro_export]
macro_rules! update_data_sql {
    ($service:expr,$sql:expr,[$($params:expr),*$(,)?]) => {
        {
            let result=sqlx::query($sql)
            $(
                .bind($params)
            )*
            .execute(&$service.pool).await?;
            let row_affected=result.rows_affected();
            if row_affected==0{
                return Err(ServerError::PopUpWindowError("更新失败".to_string()));
            }
            row_affected
        }
    };
}
