use redis::{Client, RedisResult, cmd};

pub struct RedisService {
    pool: Client,
}

impl RedisService {
    pub fn new(pool: Client) -> Self {
        Self { pool }
    }

    pub async fn get_conn(&self) -> RedisResult<redis::aio::Connection> {
        self.pool.get_async_connection().await
    }

    /// 设置redis缓存
    ///
    /// # 参数
    /// * `key` - 键
    /// * `value` - 值
    /// * `expire_seconds` - 过期时间
    ///
    /// # 返回值
    /// * `RedisResult<()>` - 结果
    pub async fn set(&self, key: &str, value: &str, expire_seconds: u64) -> RedisResult<()> {
        let mut conn = self.get_conn().await?;
        cmd("SET")
            .arg(key)
            .arg(value)
            .query_async::<_, ()>(&mut conn)
            .await?;

        cmd("EXPIRE")
            .arg(key)
            .arg(expire_seconds)
            .query_async::<_, ()>(&mut conn)
            .await?;

        Ok(())
    }

    /// 获取redis缓存
    ///
    /// # 参数
    /// * `key` - 键
    ///
    /// # 返回值
    pub async fn get(&self, key: &str) -> RedisResult<String> {
        let mut conn = self.get_conn().await?;
        let value: String = cmd("GET")
            .arg(key)
            .query_async::<_, String>(&mut conn)
            .await?;
        Ok(value)
    }
}
