//cargo remove 删除
//cargo add 添加
//cargo update 更新
mod app;
mod config;
mod middleware;
mod response;
mod service;
mod tool;
use crate::app::account::dispose::get_picture;
use crate::app::account::new_account::{
    add_newaccount, change_newaccount, delete_newaccount, extract_account_data, get_newaccount, independence_newaccount,
};
use crate::app::account::old_account::{
    add_oldaccount, change_oldaccount, delete_oldaccount, get_oldaccount, get_vague_oldaccount,
};
use crate::app::account::old_card::{add_oldcard, change_oldcard, delete_oldcard, get_oldcard};
use crate::app::account::sim_card::{
    add_simcard, change_simcard, delete_simcard, get_simcard, get_usable_simcard,
};
use crate::app::backup::backup::{get_backup_database, get_deploy_domain_name};
use crate::app::merchant::other::{shopsite_collectionteam, shopsite_controlteam};
use crate::app::merchant::receive_payment_site::{
    acquiring_site_on_enabled, add_receive_payment_site, change_receive_payment_site,
    delete_receive_payment_site, get_receive_payment_site,
};
use crate::app::merchant::shop_site::{
    add_shop_site, change_shop_site, delete_shop_site, get_shop_site, shop_site_on_enabled,
};
use crate::app::merchant::shop_site_order::get_shop_site_order;
use crate::app::receive::collection_team::{
    add_collection_team, change_collection_team, delete_collection_team, get_collection_team,
};
use crate::app::receive::paypal_group::{
    add_paypal_group, change_paypal_group, delete_paypal_group, get_paypal_group,
};
use crate::app::receive::risk_control_team::{
    add_risk_control_team, change_risk_control_team, delete_risk_control_team,
    get_risk_control_team,
};
use crate::app::receive::risk_order::get_risk_order;
use crate::app::user::user::login;
use crate::middleware::authentication::authentication;
use crate::service::db_service::{create_mysql_pool, create_redis_pool};
use crate::tool::mysql_tool::MysqlService;
use actix_cors::Cors;
use actix_web::{App, HttpServer, middleware::from_fn, web};
use std::sync::Arc;
use tool::redis_tool::RedisService;

struct AppState {
    redis_pool: Arc<RedisService>,
    mysql_service: Arc<MysqlService>,
}

#[actix_web::main]
async fn main() -> anyhow::Result<()> {
    let mysql_pool = create_mysql_pool().await?;
    let redis_pool = create_redis_pool().await?;

    let app_state = web::Data::new(AppState {
        mysql_service: Arc::new(MysqlService::new(mysql_pool)),
        redis_pool: Arc::new(RedisService::new(redis_pool)),
    });

    HttpServer::new(move || {
        let cors = Cors::default()
            .allowed_origin("https://wsuuas.top")
            .allowed_origin("https://wsuuus.info")
            .allowed_origin("http://localhost:8080")
            .allowed_methods(vec!["GET", "POST", "PUT", "DELETE", "OPTIONS"])
            .allowed_headers(vec![
                "Authorization",
                "Content-Type",
                "Accept",
                "X-Requested-With",
                "xauthtoken",
            ])
            .expose_headers(vec!["*"])
            .supports_credentials()
            .max_age(3600);

        App::new().app_data(app_state.clone()).wrap(cors).service(
            web::scope("/v1")
                .wrap(from_fn(authentication))
                .service(login) // 登录
                .service(get_deploy_domain_name) // 获取部署域名
                .service(get_backup_database) // 获取备份数据库
                .service(get_picture) // 获取图片
                .service(add_newaccount) // 新增新账号
                .service(get_newaccount) // 查询新账号
                .service(change_newaccount) // 修改新账号
                .service(delete_newaccount) // 删除新账号
                .service(independence_newaccount) // 独立新增新账号
                .service(extract_account_data) // 提取账号数据
                .service(add_oldaccount) // 新增旧账号
                .service(delete_oldaccount) // 删除旧账号
                .service(change_oldaccount) // 修改旧账号
                .service(get_oldaccount) // 获取旧账号
                .service(get_vague_oldaccount) // 模糊查询旧账号
                .service(add_shop_site) // 新增店铺
                .service(change_shop_site) // 修改店铺
                .service(delete_shop_site) // 删除店铺
                .service(get_shop_site) // 获取店铺
                .service(shop_site_on_enabled) // 修改店铺状态
                .service(add_receive_payment_site) // 新增收款网站
                .service(change_receive_payment_site) // 修改收款网站
                .service(delete_receive_payment_site) // 删除收款网站
                .service(get_receive_payment_site) // 获取收款网站
                .service(add_paypal_group) // 新增paypal组
                .service(change_paypal_group) // 修改paypal组
                .service(delete_paypal_group) // 删除paypal组
                .service(acquiring_site_on_enabled) // 修改收款网站状态
                .service(shopsite_collectionteam) // 获取收款组
                .service(shopsite_controlteam) // 获取风控组
                .service(add_collection_team) // 新增收款组
                .service(get_collection_team) // 获取收款组
                .service(change_collection_team) // 修改收款组
                .service(delete_collection_team) // 删除收款组
                .service(add_risk_control_team) // 新增风控组
                .service(get_risk_control_team) // 获取风控组
                .service(get_shop_site_order) // 获取店铺订单
                .service(get_paypal_group) // 获取paypal组
                .service(get_risk_order) // 获取风控订单
                .service(get_simcard) // 获取sim卡
                .service(add_simcard) // 新增sim卡
                .service(get_usable_simcard) // 获取可用sim卡
                .service(add_oldcard) // 新增旧卡
                .service(get_oldcard) // 获取旧卡
                .service(change_oldcard) // 修改旧卡
                .service(delete_oldcard) // 删除旧卡
                .service(change_simcard) // 修改sim卡
                .service(delete_simcard) // 删除sim卡
                .service(change_risk_control_team) // 修改风控组
                .service(delete_risk_control_team), // 删除风控组
        )
    })
    .bind(("0.0.0.0", 8080))?
    .run()
    .await?;
    Ok(())
}
