use crate::AppState;
use crate::response::ServerError;
use actix_web::Error;
use actix_web::HttpMessage;
use actix_web::dev::{ServiceRequest, ServiceResponse};
use actix_web::middleware::Next;
use actix_web::web;
use serde::{Deserialize, Serialize};
use serde_json::from_str;
const WHITELIST_PATHS: [&str; 5] = [
    "/v1/login",
    "/register",
    "/v1/get_picture",
    "/v1/get_deploy_domain_name",
    "/v1/get_backup_database",
];

/// 用户信息结构体
#[derive(Clone, Debug, Deserialize, Serialize, Default)]
pub struct UserInfo {
    pub user_id: i32,
    pub role: i32,
    pub username: String,
}

pub async fn authentication<B>(
    state: web::Data<AppState>,
    req: ServiceRequest,
    next: Next<B>,
) -> Result<ServiceResponse<B>, Error> {
    // 获取请求路径
    let path = req.path();
    // 判断请求路径是否在白名单中
    if WHITELIST_PATHS.contains(&path) {
        return next.call(req).await;
    }

    let username = match req
        .headers()
        .get("Xauthtoken")
        .and_then(|v| v.to_str().ok())
    {
        Some(token) => {
            // 分割token

            let token_parts = token.split_once(" ").unwrap();
            token_parts.0.to_string()
        }
        None => {
            return Err(Error::from(ServerError::AutoLoginServerError(
                "Token not found in request header".to_string(),
            )));
        }
    };

    //从redis中获取用户信息
    let user_key = format!("user:{}", username);

    let user_data = match state.redis_pool.get(&user_key).await {
        Ok(data) => data,
        Err(e) => {
            return Err(Error::from(ServerError::AutoLoginServerError(
                e.to_string(),
            )));
        }
    };

    match from_str::<UserInfo>(&user_data) {
        Ok(user_info) => {
            // 注入用户信息到请求扩展中
            req.extensions_mut().insert(user_info);
            next.call(req).await
        }
        Err(e) => Err(Error::from(ServerError::AutoLoginServerError(
            e.to_string(),
        ))),
    }
}
