use crate::response::ServerError;
use actix_multipart::Multipart;
use anyhow::anyhow;
use chrono::{FixedOffset, Utc};
use futures_util::StreamExt;
use serde::Deserialize;
use serde::Serialize;
use validator::Validate;

/// 删除请求参数
#[derive(Deserialize)]
pub struct DeleteRequest {
    pub ids: Vec<i32>, // 前端传的 {"ids":[2819]}
}

///生成10位时间戳 string 10位 中国时间
///
/// # 返回值
/// * `String` - 10位时间戳
pub fn generate_10_timestamp() -> String {
    let utc_now = Utc::now();
    let china_time = utc_now.with_timezone(&FixedOffset::east_opt(8 * 3600).unwrap());
    let timestamp = china_time.timestamp();
    timestamp.to_string()
}

///生成数据库格式的时间，如 YYYY-MM-DD HH:MM:SS，中国时区
///
/// # 返回值
/// * `String` - 数据库格式的时间字符串
pub fn generate_database_time() -> String {
    let utc_now = Utc::now();
    let china_time = utc_now.with_timezone(&FixedOffset::east_opt(8 * 3600).unwrap());
    china_time.format("%Y-%m-%d %H:%M:%S").to_string()
}

/// 对比 请求数据 跟 当前数据 生成 更新sql
///
/// # 参数
/// * `request` - 请求数据
/// * `current_data` - 当前数据
///
/// # 返回值
/// * `Result<(Vec<String>, Vec<String>)>` - 更新sql
pub fn update_data_map_createsql<T, U>(
    request: &T,
    current_data: &U,
) -> anyhow::Result<(Vec<String>, Vec<String>)>
where
    T: Serialize,
    U: Serialize,
{
    let mut fields_update: Vec<String> = Vec::new();
    let mut params_update: Vec<String> = Vec::new();

    // 将请求数据 跟 当前数据 转换为 json
    let request_json = serde_json::to_value(&request)?;
    let current_json = serde_json::to_value(&current_data)?;

    for (key, value) in request_json.as_object().unwrap() {
        if key == "id" {
            continue;
        }

        // 统一处理两个值
        let value_str = match value {
            serde_json::Value::String(s) => s.to_string(),
            serde_json::Value::Number(n) => n.to_string(),
            serde_json::Value::Null => "".to_string(),
            _ => value.to_string().trim_matches('"').to_string(),
        };

        let current_value_str = match &current_json[key] {
            serde_json::Value::String(s) => s.to_string(),
            serde_json::Value::Number(n) => n.to_string(),
            serde_json::Value::Null => "".to_string(),
            _ => current_json[key].to_string().trim_matches('"').to_string(),
        };

        // 判断 当前数据 跟 请求数据 是否一致
        if current_value_str != value_str {
            fields_update.push(format!("{} = ?", key));
            params_update.push(value_str);
        }
    }

    Ok((fields_update, params_update))
}

/// 处理字段的通用函数
pub async fn read_field<T>(mut multipart: Multipart) -> Result<(String, Vec<u8>, T), ServerError>
where
    T: for<'de> Deserialize<'de> + std::fmt::Debug + Default + Validate,
{
    const MAX_FILE_SIZE: usize = 5 * 1024 * 1024; // 5MB
    const ALLOWED_EXTENSIONS: [&str; 5] = ["jpg", "jpeg", "png", "xlsx", "xls"];
    let mut filename = String::new();
    let mut content = Vec::new();
    let mut request = T::default();

    // 处理字段
    for _ in 0..2 {
        if let Some(Ok(mut field)) = multipart.next().await {
            let field_name = field.name();
            match field_name {
                Some("image") => {
                    // 获取文件名和扩展名
                    let fname = field
                        .content_disposition()
                        .ok_or_else(|| anyhow!("无法获取文件名"))?
                        .get_filename()
                        .ok_or_else(|| anyhow!("无法获取文件名"))?
                        .to_string();
                    let extension = fname.rsplit('.').next().unwrap().to_lowercase();
                    if !ALLOWED_EXTENSIONS.contains(&extension.as_str()) {
                        return Err(ServerError::OtherServerError(anyhow!(
                            "不支持的文件类型: {extension}"
                        )));
                    }

                    // 获取文件内容  判断内容为空 返回错误
                    let mut bytes = Vec::new();
                    while let Some(chunk) = field.next().await {
                        let chunk = chunk.map_err(|e| anyhow::Error::msg(e.to_string()))?;
                        bytes.extend_from_slice(&chunk);
                    }

                    if bytes.is_empty() {
                        return Err(ServerError::OtherServerError(anyhow!(
                            "文件内容为空: {fname}"
                        )));
                    }

                    // 判断文件大小
                    if bytes.len() > MAX_FILE_SIZE {
                        return Err(ServerError::OtherServerError(anyhow!(
                            "文件大小超过限制: {} bytes",
                            bytes.len()
                        )));
                    }

                    // 设置文件名和内容
                    filename = fname;
                    content = bytes;
                }
                Some("metadata") => {
                    // 处理元数据
                    let mut value = String::new();
                    while let Some(chunk) = field.next().await {
                        let chunk = chunk.map_err(|e| anyhow::Error::msg(e.to_string()))?;
                        value.push_str(&String::from_utf8_lossy(&chunk));
                    }
                    let data = serde_json::from_str::<T>(&value)?;
                    data.validate()?;
                    request = data;
                }
                Some(name) => {
                    return Err(ServerError::OtherServerError(anyhow!(
                        "收到未知字段: {}",
                        name
                    )));
                }
                None => {}
            }
        }
    }
    Ok((filename, content, request))
}
