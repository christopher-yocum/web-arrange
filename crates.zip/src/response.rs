use crate::tool::mysql_tool::MySqlError;
use actix_web::{
    HttpRequest, HttpResponse, HttpResponseBuilder, Responder, ResponseError,
    body::{BoxBody, EitherBody},
    http::StatusCode,
};
use serde::Serialize;
use serde_json::json;
use thiserror::Error;
use validator::ValidationErrors;
#[derive(Error, Debug)]
pub enum ServerError {
    #[error(transparent)]
    MysqlServerError(#[from] MySqlError),
    #[error(transparent)]
    MysqlServer2Error(#[from] sqlx::Error),
    #[error(transparent)]
    RedisServerError(#[from] redis::RedisError),
    #[error(transparent)]
    OtherServerError(#[from] anyhow::Error),
    #[error(transparent)]
    ValidateServerError(#[from] ValidationErrors),
    #[error(transparent)]
    SerdeServerError(#[from] serde_json::Error),
    #[error("login error:{0}")]
    LoginServerError(String),
    #[error("pop up window error:{0}")]
    PopUpWindowError(String),
    #[error("auto login error:{0}")]
    AutoLoginServerError(String),
    #[error(transparent)]
    ContinueServerError(#[from] actix_web::error::Error),
}
impl ServerError {
    fn code(&self) -> i32 {
        match self {
            Self::LoginServerError(_) => 2001,
            Self::ValidateServerError(_) => 2001,
            Self::PopUpWindowError(_) => 2001,
            Self::AutoLoginServerError(_) => 5001,
            _ => 201,
        }
    }
}

pub struct JsonOk<T>(pub T);
impl<T: Serialize> Responder for JsonOk<T> {
    type Body = EitherBody<String>;

    fn respond_to(self, _: &HttpRequest) -> HttpResponse<Self::Body> {
        let response = json!({
            "code":200,
            "msg":"success",
            "data":self.0
        });

        HttpResponse::Ok().json(response).map_into_right_body()
    }
}

/// 返回图片
pub struct ImageOk(pub Vec<u8>);
impl Responder for ImageOk {
    type Body = BoxBody;
    fn respond_to(self, _: &HttpRequest) -> HttpResponse<Self::Body> {
        HttpResponse::Ok()
            .insert_header(("Content-Type", "image/jpeg"))
            .insert_header(("Cache-Control", "public, max-age=3600"))
            .body(self.0)
    }
}

/// 返回结果
pub type ServerResult<T> = Result<JsonOk<T>, ServerError>;
impl ResponseError for ServerError {
    fn status_code(&self) -> actix_web::http::StatusCode {
        StatusCode::OK
    }

    fn error_response(&self) -> actix_web::HttpResponse<actix_web::body::BoxBody> {
        match self {
            ServerError::ContinueServerError(e) => e.error_response(),
            other => HttpResponseBuilder::new(other.status_code())
                .json(json!({
                    "code":other.code(),
                    "msg":other.to_string()
                }))
                .map_into_boxed_body(),
        }
    }
}
